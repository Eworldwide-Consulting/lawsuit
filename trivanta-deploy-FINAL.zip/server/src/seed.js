require('dotenv').config({ path: require('path').join(__dirname, '../../.env') });
const bcrypt   = require('bcryptjs');
const supabase = require('./supabase');

async function seed() {
  console.log('🌱 Seeding Supabase database...');
  const hash = await bcrypt.hash('Password123!', 12);

  // Insert demo users
  const { data: users, error: ue } = await supabase.from('users').upsert([
    { first_name:'Admin',   last_name:'Partner',  email:'partner@trivanta.com',  password_hash:hash, role:'partner',  avatar_initials:'AP', email_verified:true },
    { first_name:'Sarah',   last_name:'Johnson',  email:'attorney@trivanta.com', password_hash:hash, role:'attorney', avatar_initials:'SJ', email_verified:true },
    { first_name:'Michael', last_name:'Davis',    email:'client@trivanta.com',   password_hash:hash, role:'client',   avatar_initials:'MD', email_verified:true },
  ], { onConflict: 'email' }).select();
  if (ue) { console.error('Users error:', ue.message); return; }
  console.log('✅ Users created');

  const partner  = users.find(u => u.email === 'partner@trivanta.com');
  const attorney = users.find(u => u.email === 'attorney@trivanta.com');
  const client   = users.find(u => u.email === 'client@trivanta.com');

  // Check if matter already exists
  const { data: existingMatter } = await supabase.from('matters').select('id').eq('client_id', client.id).maybeSingle();
  if (existingMatter) { console.log('✅ Demo data already exists — skipping'); return; }

  const importantDate = new Date(Date.now() + 30*86400000).toISOString().slice(0,10);
  const { data: matter, error: me } = await supabase.from('matters').insert({
    client_id: client.id, attorney_id: attorney.id,
    matter_type: 'guardianship', stage: 'hearing_prep', status: 'active',
    description: 'Guardianship for elderly parent', case_number: '26-0001',
    court: 'Fulton County Superior Court', county: 'Fulton', important_date: importantDate,
  }).select().single();
  if (me) { console.error('Matter error:', me.message); return; }
  console.log('✅ Matter created');

  const d = n => new Date(Date.now() + n*86400000).toISOString().slice(0,10);
  await supabase.from('tasks').insert([
    { matter_id:matter.id, assigned_to:client.id, title:'Upload medical records',     description:'Physician statements required', due_date:d(7),  priority:'high',   action_label:'Upload',  status:'pending' },
    { matter_id:matter.id, assigned_to:client.id, title:'Review petition draft',      description:'Review and confirm details',    due_date:d(10), priority:'high',   action_label:'Review',  status:'pending' },
    { matter_id:matter.id, assigned_to:client.id, title:'Sign guardianship forms',    description:'Notarized signature required',  due_date:d(14), priority:'normal', action_label:'Sign',    status:'pending' },
    { matter_id:matter.id, assigned_to:client.id, title:'Confirm hearing attendance', description:'Court hearing confirmation',    due_date:d(28), priority:'normal', action_label:'Confirm', status:'pending' },
  ]);
  console.log('✅ Tasks created');

  await supabase.from('documents').insert([
    { matter_id:matter.id, user_id:client.id, name:'Medical Records',      category:'1. Medical Documentation', status:'pending',  required:true },
    { matter_id:matter.id, user_id:client.id, name:'Financial Statements', category:'2. Financial Records',     status:'pending',  required:true },
    { matter_id:matter.id, user_id:client.id, name:'Birth Certificate',    category:'3. Identity Documents',    status:'uploaded', required:true },
    { matter_id:matter.id, user_id:client.id, name:'Court Petition',       category:'4. Legal Filings',         status:'uploaded', required:true },
  ]);
  console.log('✅ Documents created');

  await supabase.from('appointments').insert({
    matter_id:matter.id, title:'Initial Consultation', type:'teleconference',
    start_time: new Date(Date.now() + 5*86400000).toISOString(), location:'Zoom — link in email',
  });

  await supabase.from('messages').insert({
    matter_id:matter.id, from_user_id:attorney.id, to_user_id:client.id,
    subject:'Welcome to TriVanta',
    body:'Hi Michael, welcome! We have received your case details. Please complete the document uploads when you can.',
  });

  console.log('✅ Appointments & messages created');
  console.log('\n🎉 Seed complete!');
  console.log('   partner@trivanta.com  / Password123!');
  console.log('   attorney@trivanta.com / Password123!');
  console.log('   client@trivanta.com   / Password123!');
}

seed().catch(err => { console.error('Seed failed:', err.message); process.exit(1); });
