const router   = require('express').Router();
const supabase = require('../supabase');
const { requireAuth } = require('../middleware/auth');

const getStripe = () => {
  if (!process.env.STRIPE_SECRET_KEY) return null;
  return require('stripe')(process.env.STRIPE_SECRET_KEY);
};

router.get('/', requireAuth, async (req, res) => {
  try {
    let q = supabase.from('invoices').select('*, client:client_id(first_name,last_name), matter:matter_id(case_number)').order('created_at', { ascending: false });
    if (req.user.role === 'client') q = q.eq('client_id', req.user.id);
    const { data, error } = await q;
    if (error) throw error;
    res.json((data||[]).map(i => ({ ...i, client_name: i.client ? `${i.client.first_name} ${i.client.last_name}` : null, case_number: i.matter?.case_number, client: undefined, matter: undefined })));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/invoice', requireAuth, async (req, res) => {
  if (req.user.role === 'client') return res.status(403).json({ error: 'Forbidden' });
  const { clientId, matterId, amount, description, serviceType, dueDate } = req.body;
  if (!clientId || !amount || !description) return res.status(400).json({ error: 'clientId, amount, and description required' });
  const { data, error } = await supabase.from('invoices').insert({ client_id: clientId, matter_id: matterId||null, created_by: req.user.id, amount: Math.round(amount*100), description, service_type: serviceType||'general', due_date: dueDate||null, status: 'pending' }).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

router.post('/checkout/:invoiceId', requireAuth, async (req, res) => {
  const stripe = getStripe();
  if (!stripe) return res.status(501).json({ error: 'Payment processing not configured.' });
  const { data: inv } = await supabase.from('invoices').select('*').eq('id', req.params.invoiceId).maybeSingle();
  if (!inv) return res.status(404).json({ error: 'Invoice not found' });
  if (inv.client_id !== req.user.id && req.user.role === 'client') return res.status(403).json({ error: 'Forbidden' });
  if (inv.status === 'paid') return res.status(400).json({ error: 'Already paid' });
  try {
    const clientUrl = process.env.CLIENT_URL || 'http://localhost:5173';
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'], mode: 'payment',
      line_items: [{ price_data: { currency: 'usd', unit_amount: inv.amount, product_data: { name: inv.description } }, quantity: 1 }],
      metadata: { invoiceId: String(inv.id) },
      success_url: `${clientUrl}/payments/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:  `${clientUrl}/payments?cancelled=1`,
      customer_email: req.user.email,
    });
    await supabase.from('invoices').update({ stripe_session_id: session.id }).eq('id', inv.id);
    res.json({ url: session.url });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/webhook', async (req, res) => {
  const stripe = getStripe();
  if (!stripe) return res.status(200).json({ received: true });
  try {
    const event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], process.env.STRIPE_WEBHOOK_SECRET);
    if (event.type === 'checkout.session.completed') {
      const s = event.data.object;
      if (s.metadata?.invoiceId) await supabase.from('invoices').update({ status: 'paid', paid_at: new Date().toISOString(), stripe_payment_intent_id: s.payment_intent }).eq('id', s.metadata.invoiceId);
    }
    res.json({ received: true });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/confirm/:sessionId', requireAuth, async (req, res) => {
  const stripe = getStripe();
  if (!stripe) return res.status(501).json({ error: 'Stripe not configured' });
  try {
    const session = await stripe.checkout.sessions.retrieve(req.params.sessionId);
    if (session.payment_status === 'paid' && session.metadata?.invoiceId) {
      await supabase.from('invoices').update({ status: 'paid', paid_at: new Date().toISOString(), stripe_payment_intent_id: session.payment_intent }).eq('id', session.metadata.invoiceId).neq('status', 'paid');
      const { data: invoice } = await supabase.from('invoices').select('*').eq('id', session.metadata.invoiceId).single();
      return res.json({ paid: true, invoice });
    }
    res.json({ paid: false });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
