const router    = require('express').Router();
const bcrypt    = require('bcryptjs');
const jwt       = require('jsonwebtoken');
const crypto    = require('crypto');
const speakeasy = require('speakeasy');
const supabase  = require('../supabase');
const { requireAuth } = require('../middleware/auth');

let sendVerificationEmail = async () => false;
try { ({ sendVerificationEmail } = require('../email')); } catch {}

const signToken = id =>
  jwt.sign({ userId: id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

router.get('/check-email', async (req, res) => {
  const { email } = req.query;
  if (!email) return res.status(400).json({ error: 'email required' });
  const { data } = await supabase.from('users').select('id').eq('email', email.toLowerCase()).maybeSingle();
  res.json({ exists: !!data });
});

router.post('/register', async (req, res) => {
  try {
    const { firstName, lastName, email, password, phone, dob, street, city, state, zip, role,
            barNumber, stateBar, yearsExperience, specializations, firmRole, practiceGroups } = req.body;
    if (!firstName || !lastName || !email || !password)
      return res.status(400).json({ error: 'Required fields missing' });
    if (password.length < 8)
      return res.status(400).json({ error: 'Password must be at least 8 characters' });

    const { data: existing } = await supabase.from('users').select('id').eq('email', email.toLowerCase()).maybeSingle();
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    const hash     = await bcrypt.hash(password, 12);
    const initials = `${firstName[0]}${lastName[0]}`.toUpperCase();
    const userRole = ['attorney', 'partner'].includes(role) ? role : 'client';
    const isPro    = ['attorney', 'partner'].includes(userRole);
    const verToken = crypto.randomBytes(32).toString('hex');
    const verExp   = new Date(Date.now() + 24*60*60*1000).toISOString();

    const { data: user, error } = await supabase.from('users').insert({
      first_name: firstName, last_name: lastName, email: email.toLowerCase(),
      password_hash: hash, role: userRole, phone: phone||null, dob: dob||null,
      street: street||null, city: city||null, state: state||null, zip: zip||null,
      avatar_initials: initials, email_verified: false,
      verification_token: verToken, verification_token_expires: verExp,
      approval_status: isPro ? 'pending' : null,
    }).select('id,first_name,last_name,email,role').single();

    if (error) throw error;

    if (isPro) {
      await supabase.from('user_profiles').insert({
        user_id: user.id, bar_number: barNumber||null, state_bar: stateBar||null,
        years_experience: yearsExperience ? parseInt(yearsExperience) : null,
        specializations: specializations||null, firm_role: firmRole||null,
        practice_groups: practiceGroups||null,
      }).catch(() => {});
    }

    sendVerificationEmail(user.email, verToken).catch(() => {});
    res.status(201).json({ requiresVerification: true, requiresApproval: isPro, email: user.email, role: userRole });
  } catch (err) {
    console.error('Register error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

router.get('/verify-email', async (req, res) => {
  const { token } = req.query;
  if (!token) return res.status(400).json({ error: 'Token required' });
  const { data: user } = await supabase.from('users').select('id,email_verified,verification_token_expires')
    .eq('verification_token', token).maybeSingle();
  if (!user) return res.status(400).json({ error: 'Invalid or expired link' });
  if (user.email_verified) return res.json({ alreadyVerified: true });
  if (new Date(user.verification_token_expires) < new Date())
    return res.status(400).json({ error: 'Link expired. Please request a new one.' });
  await supabase.from('users').update({ email_verified: true, verification_token: null, verification_token_expires: null }).eq('id', user.id);
  res.json({ verified: true });
});

router.post('/resend-verification', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });
  const { data: user } = await supabase.from('users').select('id,email,email_verified').eq('email', email.toLowerCase()).maybeSingle();
  if (!user || user.email_verified) return res.json({ sent: true });
  const verToken = crypto.randomBytes(32).toString('hex');
  const verExp   = new Date(Date.now() + 24*60*60*1000).toISOString();
  await supabase.from('users').update({ verification_token: verToken, verification_token_expires: verExp }).eq('id', user.id);
  sendVerificationEmail(user.email, verToken).catch(() => {});
  res.json({ sent: true });
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    const { data: user } = await supabase.from('users').select('*').eq('email', email.toLowerCase()).maybeSingle();
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    if (!await bcrypt.compare(password, user.password_hash || ''))
      return res.status(401).json({ error: 'Invalid credentials' });
    if (!user.email_verified && user.password_hash)
      return res.status(403).json({ error: 'Please verify your email.', requiresVerification: true, email: user.email });
    if (user.approval_status === 'pending')
      return res.status(403).json({ error: 'Account pending review.', requiresApproval: true });
    if (user.approval_status === 'rejected')
      return res.status(403).json({ error: 'Account application was not approved.', requiresApproval: true });
    if (user.two_fa_enabled) {
      const tmp = jwt.sign({ userId: user.id, twoFaPending: true }, process.env.JWT_SECRET, { expiresIn: '10m' });
      return res.json({ twoFaRequired: true, tempToken: tmp });
    }
    const safeUser = { id: user.id, first_name: user.first_name, last_name: user.last_name, email: user.email, role: user.role, avatar_initials: user.avatar_initials };
    res.json({ token: signToken(user.id), user: safeUser });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/verify-2fa', async (req, res) => {
  try {
    const { tempToken, code } = req.body;
    const payload = jwt.verify(tempToken, process.env.JWT_SECRET);
    if (!payload.twoFaPending) return res.status(400).json({ error: 'Invalid token' });
    const { data: user } = await supabase.from('users').select('*').eq('id', payload.userId).single();
    if (!speakeasy.totp.verify({ secret: user.two_fa_secret, encoding: 'base32', token: code, window: 2 }))
      return res.status(401).json({ error: 'Invalid code' });
    const safeUser = { id: user.id, first_name: user.first_name, last_name: user.last_name, email: user.email, role: user.role, avatar_initials: user.avatar_initials };
    res.json({ token: signToken(user.id), user: safeUser });
  } catch { res.status(401).json({ error: 'Invalid or expired token' }); }
});

router.post('/setup-2fa', requireAuth, async (req, res) => {
  const secret = speakeasy.generateSecret({ name: `TriVanta (${req.user.email})` });
  await supabase.from('users').update({ two_fa_secret: secret.base32 }).eq('id', req.user.id);
  res.json({ secret: secret.base32, otpauth_url: secret.otpauth_url });
});

router.post('/enable-2fa', requireAuth, async (req, res) => {
  if (!speakeasy.totp.verify({ secret: req.user.two_fa_secret, encoding: 'base32', token: req.body.code, window: 2 }))
    return res.status(400).json({ error: 'Invalid code' });
  await supabase.from('users').update({ two_fa_enabled: true }).eq('id', req.user.id);
  res.json({ success: true });
});

router.get('/me', requireAuth, (req, res) => {
  const { id, first_name, last_name, email, role, phone, avatar_initials } = req.user;
  res.json({ id, first_name, last_name, email, role, phone, avatar_initials });
});

router.put('/profile', requireAuth, async (req, res) => {
  const { firstName, lastName, phone } = req.body;
  await supabase.from('users').update({ first_name: firstName, last_name: lastName, phone: phone||null }).eq('id', req.user.id);
  res.json({ success: true });
});

router.put('/change-password', requireAuth, async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) return res.status(400).json({ error: 'Both passwords required' });
  if (newPassword.length < 8) return res.status(400).json({ error: 'Min 8 characters' });
  if (!await bcrypt.compare(currentPassword, req.user.password_hash || ''))
    return res.status(400).json({ error: 'Current password incorrect' });
  await supabase.from('users').update({ password_hash: await bcrypt.hash(newPassword, 12) }).eq('id', req.user.id);
  res.json({ success: true });
});

// ── Google OAuth ──────────────────────────────────────────────────────────────
const googleCB = () => `${process.env.SERVER_URL || process.env.CLIENT_URL}/api/auth/google/callback`;

router.get('/google', (req, res) => {
  if (!process.env.GOOGLE_CLIENT_ID) return res.status(501).send('Google sign-in not configured.');
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID, redirect_uri: googleCB(),
    response_type: 'code', scope: 'openid email profile', access_type: 'offline', prompt: 'select_account',
  })}`);
});

router.get('/google/callback', async (req, res) => {
  const clientUrl = process.env.CLIENT_URL || 'http://localhost:5173';
  const { code, error } = req.query;
  if (error || !code) return res.redirect(`${clientUrl}/login?error=google_cancelled`);
  try {
    const tokens = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ code, client_id: process.env.GOOGLE_CLIENT_ID,
        client_secret: process.env.GOOGLE_CLIENT_SECRET, redirect_uri: googleCB(), grant_type: 'authorization_code' }).toString(),
    }).then(r => r.json());
    if (tokens.error) throw new Error(tokens.error_description);
    const gUser = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', { headers: { Authorization: `Bearer ${tokens.access_token}` } }).then(r => r.json());
    if (!gUser.email) throw new Error('No email from Google');
    if (!gUser.verified_email) return res.redirect(`${clientUrl}/login?error=google_unverified`);
    let { data: user } = await supabase.from('users').select('*').eq('email', gUser.email.toLowerCase()).maybeSingle();
    if (!user) {
      const fn = gUser.given_name || gUser.name?.split(' ')[0] || 'User';
      const ln = gUser.family_name || gUser.name?.split(' ').slice(1).join(' ') || '';
      const { data: created } = await supabase.from('users').insert({
        first_name: fn, last_name: ln, email: gUser.email.toLowerCase(),
        password_hash: '', role: 'client',
        avatar_initials: `${fn[0]}${(ln[0]||fn[1]||'U')}`.toUpperCase(), email_verified: true,
      }).select('*').single();
      user = created;
    }
    res.redirect(`${clientUrl}/auth/callback?token=${encodeURIComponent(signToken(user.id))}`);
  } catch (err) {
    console.error('Google OAuth error:', err.message);
    res.redirect(`${clientUrl}/login?error=google_failed`);
  }
});

module.exports = router;
