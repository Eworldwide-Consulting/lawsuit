const router   = require('express').Router();
const supabase = require('../supabase');
const { requireAuth, requireRole } = require('../middleware/auth');

const guard = [requireAuth, requireRole('itsupport','partner')];

router.get('/stats', ...guard, async (req, res) => {
  try {
    const [users, matters, documents, messages, appointments, tasks] = await Promise.all([
      supabase.from('users').select('*', { count: 'exact', head: true }),
      supabase.from('matters').select('*', { count: 'exact', head: true }),
      supabase.from('documents').select('*', { count: 'exact', head: true }),
      supabase.from('messages').select('*', { count: 'exact', head: true }),
      supabase.from('appointments').select('*', { count: 'exact', head: true }),
      supabase.from('tasks').select('*', { count: 'exact', head: true }),
    ]);
    res.json({ users: users.count, matters: matters.count, documents: documents.count, messages: messages.count, appointments: appointments.count, tasks: tasks.count });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/users', ...guard, async (req, res) => {
  try {
    const { data, error } = await supabase.from('users').select('id,first_name,last_name,email,role,email_verified,approval_status,created_at').order('created_at', { ascending: false });
    if (error) throw error;
    res.json(data||[]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/users/:id/approve', ...guard, async (req, res) => {
  try {
    await supabase.from('users').update({ approval_status: 'approved' }).eq('id', req.params.id);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/users/:id/reject', ...guard, async (req, res) => {
  try {
    await supabase.from('users').update({ approval_status: 'rejected' }).eq('id', req.params.id);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
