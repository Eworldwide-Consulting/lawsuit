const router = require('express').Router();
const crypto = require('crypto');
const { one, all, run }   = require('../db');
const { requireAuth, requireRole, invalidateUserCache } = require('../middleware/auth');
const UserRepo        = require('../repositories/user.repository');
const EmailService    = require('../services/email.service');
const { in24Hours }   = require('../lib/dates');
const { parsePagination } = require('../lib/pagination');
const config          = require('../config');
const AuditService    = require('../services/audit.service');

const guard = [requireAuth, requireRole('itsupport', 'partner')];

router.get('/stats', ...guard, async (req, res, next) => {
  try {
    const row = await one(`
      SELECT
        (SELECT COUNT(*) FROM users)        AS users,
        (SELECT COUNT(*) FROM matters)      AS matters,
        (SELECT COUNT(*) FROM documents)    AS documents,
        (SELECT COUNT(*) FROM messages)     AS messages,
        (SELECT COUNT(*) FROM appointments) AS appointments,
        (SELECT COUNT(*) FROM tasks)        AS tasks
    `);
    res.json({
      users:        Number(row.users),
      matters:      Number(row.matters),
      documents:    Number(row.documents),
      messages:     Number(row.messages),
      appointments: Number(row.appointments),
      tasks:        Number(row.tasks),
    });
  } catch (err) { next(err); }
});

router.get('/users', ...guard, async (req, res, next) => {
  try {
    const { limit, offset } = parsePagination(req.query);
    res.json(await UserRepo.findAll({ limit, offset }));
  } catch (err) { next(err); }
});

router.get('/users/by-email', ...guard, async (req, res, next) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ error: 'email required' });
    const user = await UserRepo.findByEmailSafe(email);
    if (!user) return res.status(404).json({ error: 'User not found', registered: false });
    res.json({ registered: true, user });
  } catch (err) { next(err); }
});

router.post('/users/:id/force-verify', ...guard, async (req, res, next) => {
  try {
    const user = await one('SELECT id, email, email_verified FROM users WHERE id = ?', [req.params.id]);
    if (!user) return res.status(404).json({ error: 'User not found' });
    await UserRepo.markVerified(req.params.id);
    await invalidateUserCache(req.params.id);
    AuditService.log({
      userId: req.user.id, action: AuditService.ACTIONS.ADMIN_FORCE_VERIFY,
      entity: 'user', entityId: req.params.id,
      meta: { targetEmail: user.email },
      ip: req.ip,
    });
    res.json({ success: true, email: user.email, was_verified: !!user.email_verified });
  } catch (err) { next(err); }
});

router.post('/users/:id/resend-verification', ...guard, async (req, res, next) => {
  try {
    const user = await one('SELECT id, email, email_verified FROM users WHERE id = ?', [req.params.id]);
    if (!user) return res.status(404).json({ error: 'User not found' });
    if (user.email_verified) return res.json({ success: true, note: 'Already verified' });
    const token = crypto.randomBytes(32).toString('hex');
    await UserRepo.setVerificationToken(user.id, token, in24Hours());
    // H2: send link via email only — never return it in the API response (it gets logged)
    EmailService.sendVerification(user.email, token);
    AuditService.log({
      userId: req.user.id, action: AuditService.ACTIONS.ADMIN_RESEND_VERIFY,
      entity: 'user', entityId: req.params.id,
      meta: { targetEmail: user.email },
      ip: req.ip,
    });
    res.json({ success: true, email: user.email });
  } catch (err) { next(err); }
});

router.put('/users/:id/approve', ...guard, async (req, res, next) => {
  try {
    await UserRepo.setApprovalStatus(req.params.id, 'approved');
    await invalidateUserCache(req.params.id);
    AuditService.log({
      userId: req.user.id, action: AuditService.ACTIONS.ADMIN_APPROVE_USER,
      entity: 'user', entityId: req.params.id,
      ip: req.ip,
    });
    res.json({ success: true });
  } catch (err) { next(err); }
});

router.put('/users/:id/reject', ...guard, async (req, res, next) => {
  try {
    await UserRepo.setApprovalStatus(req.params.id, 'rejected');
    await invalidateUserCache(req.params.id);
    AuditService.log({
      userId: req.user.id, action: AuditService.ACTIONS.ADMIN_REJECT_USER,
      entity: 'user', entityId: req.params.id,
      ip: req.ip,
    });
    res.json({ success: true });
  } catch (err) { next(err); }
});

module.exports = router;